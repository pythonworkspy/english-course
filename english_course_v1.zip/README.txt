English Course v1

GitHub Pages kök klasörüne iki dosyayı yükleyin:
- index.html
- course-data.js

İlk kurulumdan sonra normalde sadece course-data.js güncellenecek.
İlerleme localStorage içinde tutulur; GitHub'a gönderilmez.
